export const colors = [
  "#800080",
  "#FFA500",
  "#ff0000",
  "#f8ff00",
  "#a41a1a",
  "#10ff00",
  "#00ffd9",
];
