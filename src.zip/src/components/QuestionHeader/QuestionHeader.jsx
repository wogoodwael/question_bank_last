import React from "react";

const QuestionHeader = () => {
  return <div>QuestionHeader</div>;
};

export default QuestionHeader;
